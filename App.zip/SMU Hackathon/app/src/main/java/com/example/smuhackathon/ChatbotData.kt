package com.example.smuhackathon

data class chatbotData(
    var query: String,
    var botuser: String
)
