package com.example.smuhackathon

data class LegalData(
    var date: String,
    var name: String,
    var paragraph : String
)
