package com.example.smuhackathon

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatbotActivity : AppCompatActivity() {

    val datalist2 = mutableListOf<chatbotData>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatbot)

        val recyclerView2 = findViewById<RecyclerView>(R.id.chatbotrecyclerview)
        recyclerView2.adapter = chatbotAdapter()
        recyclerView2.layoutManager =
            LinearLayoutManager(this@ChatbotActivity, LinearLayoutManager.VERTICAL, false)
        (recyclerView2.adapter as chatbotAdapter).submitList(datalist2)

        findViewById<Button>(R.id.button6).setOnClickListener {
            var usertext = findViewById<TextView>(R.id.usertext).text.toString()
            findViewById<TextView>(R.id.usertext).text = ""
            datalist2.add(
                chatbotData(
                    query = usertext,
                    botuser = "user"
                )
            )
            (recyclerView2.adapter as chatbotAdapter).submitList(datalist2)
            (recyclerView2.adapter as chatbotAdapter).notifyDataSetChanged();

            datalist2.add(
                chatbotData(
                    query="I am not a lawyer and my advice may not be fully accurate, but I can provide you with some general information about divorce in Singapore. If your wife has cheated on you and you are considering divorce, you may have grounds for divorce under the Women's Charter, which governs marriage and divorce in Singapore.\n\nAccording to Section 95(3)(b) of the Women's Charter, adultery is one of the grounds for divorce. To be eligible for divorce, you must meet the following requirements:\n\n1. You must have been married for at least 3 years.\n2. You must be domiciled in Singapore or have lived in Singapore for at least 3 years before filing for divorce.\n\nIf you meet these requirements, you can proceed with the following steps:\n\n1. File a Writ for Divorce: You will need to file a Writ for Divorce with the Family Justice Courts. This document will state your intention to divorce and the grounds for divorce (in this case, adultery).\n\n2. Serve the Writ: The Writ for Divorce must be served to your spouse, giving them notice of the divorce proceedings.\n\n3. File an Affidavit of Service: After serving the Writ, you must file an Affidavit of Service with the court to prove that your spouse has been notified.\n\n4. Attend a Case Conference: A judge will schedule a case conference to discuss the case and determine if it can proceed to trial.\n\n5. Proceed to Trial: If the judge determines that the case can proceed to trial, both parties will present their evidence and arguments in court.\n\n6. Judgment: The judge will make a decision on the divorce and any ancillary matters, such as custody, maintenance, and division of assets.\n\nPlease note that this is a general overview and the specific steps and requirements may vary depending on your situation. For more information, you can visit the Family Justice Courts website (https://www.familyjusticecourts.gov.sg) or consult a lawyer in Singapore.\n\nIf you have any other questions about Singapore law, feel free to ask." ,
                    botuser="bot"
                )
            )
            (recyclerView2.adapter as chatbotAdapter).submitList(datalist2)
            (recyclerView2.adapter as chatbotAdapter).notifyDataSetChanged();

            //Unable to connect chatbot to app due to money constraints
//            val client = OkHttpClient()
//            val request = Request.Builder().get().url("LINK").build()
//            client.newCall(request).enqueue(object : Callback {
//                override fun onFailure(call: Call, e: IOException) {
//                    println("failed")
//                }
//                override fun onResponse(call: Call, response: Response) {
//                    var responsetext = JSONArray(response.body?.string())[0]
//                    datalist2.add(
//                        chatbotData(
//                            query = responsetext as String,
//                            botuser = "bot"
//                        )
//                    )
//                    (recyclerView2.adapter as chatbotAdapter).submitList(datalist2)
//                    (recyclerView2.adapter as chatbotAdapter).notifyDataSetChanged();
//                }
//            })
        }


    }
}