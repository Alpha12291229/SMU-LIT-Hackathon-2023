package com.example.smuhackathon

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.sql.DriverManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Cases
        findViewById<Button>(R.id.button3).setOnClickListener {
            Intent(this@MainActivity, MyCases::class.java).also{ Intent->
                startActivity(Intent)
            }
        }

        //Chatbot
        findViewById<Button>(R.id.button).setOnClickListener {
            Intent(this@MainActivity, ChatbotActivity::class.java).also{ Intent->
                startActivity(Intent)
            }
        }
    }
}