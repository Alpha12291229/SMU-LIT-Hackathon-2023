package com.example.smuhackathon

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MyCases : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_cases)

        findViewById<Button>(R.id.button5).setOnClickListener {
            Intent(this@MyCases, DistrictCourt::class.java).also{ Intent->
                startActivity(Intent)
            }
        }
    }
}