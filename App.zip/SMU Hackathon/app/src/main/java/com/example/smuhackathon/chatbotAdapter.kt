package com.example.smuhackathon

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

class chatbotAdapter : ListAdapter<chatbotData, chatbotViewholder>(chatbotComparater()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): chatbotViewholder {
        return chatbotViewholder(
            LayoutInflater.from(parent.context).inflate(R.layout.chatbotlayout, parent, false)
        )
    }

    override fun onBindViewHolder(holder: chatbotViewholder, position: Int) {
        return holder.bind(getItem(position))
    }
}

class chatbotViewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun bind(chatbotData: chatbotData) {
        if (chatbotData.botuser == "bot") {
            itemView.findViewById<TextView>(R.id.botresponse).text = chatbotData.query
            itemView.findViewById<TextView>(R.id.userresponse).visibility = View.GONE
        } else if (chatbotData.botuser == "user") {
            itemView.findViewById<TextView>(R.id.userresponse).text = chatbotData.query
            itemView.findViewById<TextView>(R.id.botresponse).visibility = View.GONE
        }
    }
}

class chatbotComparater : DiffUtil.ItemCallback<chatbotData>() {
    override fun areItemsTheSame(oldItem: chatbotData, newItem: chatbotData): Boolean {
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: chatbotData, newItem: chatbotData): Boolean {
        return oldItem.query == newItem.query
    }

}
