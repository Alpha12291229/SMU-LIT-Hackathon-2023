package com.example.smuhackathon

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.io.BufferedReader

class DistrictCourt : AppCompatActivity() {
    val datalist = mutableListOf<LegalData>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_district_court)

        //Assume we have access to the API to get the dates and names
        val inputStream2 = applicationContext.assets.open("api.json")
        val unparsedJson2 = BufferedReader(inputStream2.bufferedReader()).readText()
        val JSONArray2 = JSONObject(unparsedJson2).getJSONArray("data")

        //Reading Json File
        val inputStream = applicationContext.assets.open("data.json")
        val unparsedJson = BufferedReader(inputStream.bufferedReader()).readText()
        val JSONArray = JSONObject(unparsedJson).getJSONArray("data")


        for (i in 0 until JSONArray2.length()){
            val name = JSONArray2.getJSONObject(i).getString("name")
            val date = JSONArray2.getJSONObject(i).getString("date")
            for (j in 0 until JSONArray.length()){
                val item = JSONArray.getJSONObject(j).getString("name")
                if(name == item){
                    datalist.add(
                        LegalData(
                            name = name,
                            date = date,
                            paragraph = JSONArray.getJSONObject(j).getString("para")
                        )
                    )
                }
            }
        }
        val recyclerView =findViewById<RecyclerView>(R.id.recycleview)
        recyclerView.adapter = legaladapter()
        recyclerView.layoutManager = LinearLayoutManager(this@DistrictCourt, LinearLayoutManager.VERTICAL, false)
        (recyclerView.adapter as legaladapter).submitList(datalist)

    }
}