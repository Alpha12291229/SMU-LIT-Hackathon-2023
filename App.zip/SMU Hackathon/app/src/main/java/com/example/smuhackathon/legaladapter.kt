package com.example.smuhackathon

import android.graphics.Color
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class legaladapter : ListAdapter<LegalData, LegalViewholder>(legalComparater()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LegalViewholder {
        return LegalViewholder(
            LayoutInflater.from(parent.context).inflate(R.layout.legallayout, parent, false)
        )
    }

    override fun onBindViewHolder(holder: LegalViewholder, position: Int) {
        return holder.bind(getItem(position))
    }

}

class LegalViewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun bind(legalData: LegalData) {
        itemView.findViewById<TextView>(R.id.date).text = legalData.date
        itemView.findViewById<TextView>(R.id.name).text = legalData.name
        itemView.findViewById<TextView>(R.id.Para).text = legalData.paragraph
        itemView.findViewById<ImageView>(R.id.imageView).setOnClickListener {
            val rotation = itemView.findViewById<ImageView>(R.id.imageView).rotation
            if (rotation == (90).toFloat()) {
                itemView.findViewById<ImageView>(R.id.imageView).rotation = (-90).toFloat()
                itemView.findViewById<TextView>(R.id.name).setTextColor(Color.parseColor("#AF7F7F"))
                itemView.findViewById<TextView>(R.id.name).paintFlags = Paint.UNDERLINE_TEXT_FLAG
                itemView.findViewById<TextView>(R.id.Para).visibility = View.VISIBLE
            }else{
                itemView.findViewById<ImageView>(R.id.imageView).rotation = (90).toFloat()
                itemView.findViewById<TextView>(R.id.name).setTextColor(Color.parseColor("#757575"))
                itemView.findViewById<TextView>(R.id.name).paintFlags = Paint.ANTI_ALIAS_FLAG
                itemView.findViewById<TextView>(R.id.Para).visibility = View.GONE
            }
        }
    }
}

class legalComparater : DiffUtil.ItemCallback<LegalData>() {
    override fun areContentsTheSame(oldItem: LegalData, newItem: LegalData): Boolean {
        return oldItem.paragraph == newItem.paragraph
    }

    override fun areItemsTheSame(oldItem: LegalData, newItem: LegalData): Boolean {
        return oldItem == newItem
    }

}